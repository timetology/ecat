SELECT  mn.MachineName, se.EventUTCTime, sfn.Filename, se.FileName_Target, se.Path_Target, se.LaunchArguments_Target, sla.LaunchArguments
--SELECT se.FileName_Target, count(se.FileName_Target) as cnt
--SELECT sfn.FileName, count(sfn.FileName) as cnt
--select se.LaunchArguments_Target, count (*) as cnt
--select sla.LaunchArguments, count (*) as cnt

FROM
	--[dbo].[WinTrackingEventsCache] AS [se] WITH(NOLOCK)
	[dbo].[WinTrackingEvents_P0] AS [se] WITH(NOLOCK)
	--[dbo].[WinTrackingEvents_P1] AS [se] WITH(NOLOCK)
	INNER JOIN [dbo].[MachineModulePaths] AS [mp] WITH(NOLOCK) ON ([mp].[PK_MachineModulePaths] = [se].[FK_MachineModulePaths])
	--INNER JOIN [dbo].[Modules] AS [mo] WITH(NOLOCK) ON ([mo].[PK_Modules] = [mp].[FK_Modules])
	INNER JOIN [dbo].[FileNames] AS [sfn] WITH(NOLOCK) ON ([sfn].[PK_FileNames] = [mp].[FK_FileNames])
	INNER JOIN [dbo].[machines] AS [mn] WITH(NOLOCK) ON [mn].[PK_Machines] = [se].[FK_Machines]
	--INNER JOIN [dbo].[LinkedServers] AS [ls] WITH(NOLOCK) ON [ls].[PK_LinkedServers] = [mn].[FK_LinkedServers] 
	INNER JOIN [dbo].[LaunchArguments] AS [sla] WITH(NOLOCK) ON [sla].[PK_LaunchArguments] = [se].[FK_LaunchArguments__SourceCommandLine]

WHERE 


-- IIOC RSA_IR-New-CMD_Creates_VBS
	[se].[BehaviorFileWriteExecutable] = 1
	AND sfn.FileName = 'cmd.exe' 
	AND (
		se.FileName_Target LIKE '%.vbs' OR
		se.FileName_Target LIKE '%.vb' OR
		se.FileName_Target LIKE '%.vbe' OR
		se.FileName_Target LIKE '%.wsh' OR
		se.FileName_Target LIKE '%.wsf' OR
		se.FileName_Target LIKE '%.bat' OR
		se.FileName_Target LIKE '%.cmd' OR
		se.FileName_Target LIKE '%.reg' OR
		se.FileName_Target LIKE '%.js'
		)
	AND se.Path_Target NOT LIKE '%\progra~%' 
	AND se.Path_Target NOT LIKE '%\program %'
	AND se.Path_Target NOT LIKE '%\scripts %'
	AND se.Path_Target NOT LIKE '%\IBM_%'

	UNION

SELECT  mn.MachineName, se.EventUTCTime, sfn.Filename, se.FileName_Target, se.Path_Target, se.LaunchArguments_Target, sla.LaunchArguments
--SELECT se.FileName_Target, count(se.FileName_Target) as cnt
--SELECT sfn.FileName, count(sfn.FileName) as cnt
--select se.LaunchArguments_Target, count (*) as cnt
--select sla.LaunchArguments, count (*) as cnt

FROM
	--[dbo].[WinTrackingEventsCache] AS [se] WITH(NOLOCK)
	--[dbo].[WinTrackingEvents_P0] AS [se] WITH(NOLOCK)
	[dbo].[WinTrackingEvents_P1] AS [se] WITH(NOLOCK)
	INNER JOIN [dbo].[MachineModulePaths] AS [mp] WITH(NOLOCK) ON ([mp].[PK_MachineModulePaths] = [se].[FK_MachineModulePaths])
	--INNER JOIN [dbo].[Modules] AS [mo] WITH(NOLOCK) ON ([mo].[PK_Modules] = [mp].[FK_Modules])
	INNER JOIN [dbo].[FileNames] AS [sfn] WITH(NOLOCK) ON ([sfn].[PK_FileNames] = [mp].[FK_FileNames])
	INNER JOIN [dbo].[machines] AS [mn] WITH(NOLOCK) ON [mn].[PK_Machines] = [se].[FK_Machines]
	--INNER JOIN [dbo].[LinkedServers] AS [ls] WITH(NOLOCK) ON [ls].[PK_LinkedServers] = [mn].[FK_LinkedServers] 
	INNER JOIN [dbo].[LaunchArguments] AS [sla] WITH(NOLOCK) ON [sla].[PK_LaunchArguments] = [se].[FK_LaunchArguments__SourceCommandLine]

WHERE 

-- IIOC RSA_IR-New-CMD_Creates_VBS
	[se].[BehaviorFileWriteExecutable] = 1
	AND sfn.FileName = 'cmd.exe' 
	AND (
		se.FileName_Target LIKE '%.vbs' OR
		se.FileName_Target LIKE '%.vb' OR
		se.FileName_Target LIKE '%.vbe' OR
		se.FileName_Target LIKE '%.wsh' OR
		se.FileName_Target LIKE '%.wsf' OR
		se.FileName_Target LIKE '%.bat' OR
		se.FileName_Target LIKE '%.cmd' OR
		se.FileName_Target LIKE '%.reg' OR
		se.FileName_Target LIKE '%.js'
		)
	AND se.Path_Target NOT LIKE '%\progra~%' 
	AND se.Path_Target NOT LIKE '%\program %'
	AND se.Path_Target NOT LIKE '%\scripts %'
	AND se.Path_Target NOT LIKE '%\IBM_%'



	ORDER BY se.FileName_Target

