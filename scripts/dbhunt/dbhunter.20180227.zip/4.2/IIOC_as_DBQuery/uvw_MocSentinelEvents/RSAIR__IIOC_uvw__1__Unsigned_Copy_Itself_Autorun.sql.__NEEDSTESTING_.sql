--Unsigned_Copy_Itself_Autorun.sql	Unsigned copy itself autorun	1	

WITH IOCS_MODULES_MACHINES AS
(
	SELECT
		[ie].[FK_Modules] AS [FK_Modules],
		[ie].[FK_Machines] AS [FK_Machines]
	FROM
		[dbo].[IOCEvaluation] AS [ie] WITH(NOLOCK)
		INNER JOIN [dbo].[IOCQuery] AS [iq] WITH(NOLOCK) ON ([iq].[PK_IOCQuery] = [ie].[FK_IOCQuery])
	WHERE
		[iq].[IOCQueryID] = '31E7E202-DD03-0048-BDE4-33E2E8A3E0EE' -- Unsigned copy itself
	INTERSECT
	SELECT
		[ie].[FK_Modules] AS [FK_Modules],
		[ie].[FK_Machines] AS [FK_Machines]
	FROM
		[dbo].[IOCEvaluation] AS [ie] WITH(NOLOCK)
		INNER JOIN [dbo].[IOCQuery] AS [iq] WITH(NOLOCK) ON ([iq].[PK_IOCQuery] = [ie].[FK_IOCQuery])
	WHERE
		[iq].[IOCQueryID] = '31E7E201-DD03-0041-BDE4-33E2E8A3E0EE' -- Autorun
)
SELECT
	[mn].[MachineName]
	,[se].[EventUTCTime]
	,[sfn].[FileName]
	,[se].[Path__TargetProcessPathName]
	,[se].[FileName__TargetProcessImageFileName]
	,[se].[SourceCommandLine]
	,[se].[TargetCommandLine]
  
FROM [dbo].[uvw_mocSentinelEvents] AS [se] WITH(NOLOCK)
	INNER JOIN [dbo].[machines] AS [mn] WITH(NOLOCK) ON [mn].[PK_Machines] = [se].[FK_Machines] 
	INNER JOIN [dbo].[MachineModulePaths] AS [mp] WITH(NOLOCK) ON ([mp].[PK_MachineModulePaths] = [se].[FK_MachineModulePaths])
	INNER JOIN [dbo].[Modules] AS [mo] WITH(NOLOCK) ON ([mo].[PK_Modules] = [mp].[FK_Modules])
	INNER JOIN [dbo].[FileNames] AS [sfn] WITH(NOLOCK) ON ([sfn].[PK_FileNames] = [mp].[FK_FileNames])

	INNER JOIN IOCS_MODULES_MACHINES AS [mm] ON ([mm].[FK_Modules] = [mp].[FK_Modules] AND [mm].[FK_Machines] = [mp].[FK_Machines])
WHERE
	[mp].[MarkedAsDeleted] = 0