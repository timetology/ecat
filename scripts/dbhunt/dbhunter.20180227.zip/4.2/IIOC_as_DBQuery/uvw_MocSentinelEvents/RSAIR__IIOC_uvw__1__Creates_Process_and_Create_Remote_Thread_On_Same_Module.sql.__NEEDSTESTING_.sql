--Creates_Process_and_Create_Remote_Thread_On_Same_Module.sql	Creates process and create remote thread on same module	1	

WITH BOTH_EVENTS AS
(
SELECT
	[se].[FK_Machines],
	[se].[FK_MachineModulePaths]
	,[se].[EventUTCTime]
	,[sfn].[FileName]
	,[se].[Path__TargetProcessPathName]
	,[se].[FileName__TargetProcessImageFileName]
	,[se].[SourceCommandLine]
	,[se].[TargetCommandLine]
	,MAX(CAST([mp].[BehaviorProcessCreateProcess] AS INT)) AS [CreateProcess]
	,MAX(CAST([mp].[BehaviorProcessCreateRemoteThread] AS INT)) AS [CreateRemoteThread]

FROM [dbo].[uvw_mocSentinelEvents] AS [se] WITH(NOLOCK)
	INNER JOIN [dbo].[machines] AS [mn] WITH(NOLOCK) ON [mn].[PK_Machines] = [se].[FK_Machines] 
	INNER JOIN [dbo].[MachineModulePaths] AS [mp] WITH(NOLOCK) ON ([mp].[PK_MachineModulePaths] = [se].[FK_MachineModulePaths])
	INNER JOIN [dbo].[Modules] AS [mo] WITH(NOLOCK) ON ([mo].[PK_Modules] = [mp].[FK_Modules])
	INNER JOIN [dbo].[FileNames] AS [sfn] WITH(NOLOCK) ON ([sfn].[PK_FileNames] = [mp].[FK_FileNames])
WHERE
	(
		[mp].[BehaviorProcessCreateProcess] = 1 OR
		[mp].[BehaviorProcessCreateRemoteThread] = 1
	)
GROUP BY
	[se].[FK_Machines],
	[se].[FK_MachineModulePaths]
	,[se].[EventUTCTime]
	,[sfn].[FileName]
	,[se].[Path__TargetProcessPathName]
	,[se].[FileName__TargetProcessImageFileName]
	,[se].[SourceCommandLine]
	,[se].[TargetCommandLine]

)

SELECT
	[mn].[MachineName]
	,[be].[EventUTCTime]
	,[be].[FileName]
	,[be].[Path__TargetProcessPathName]
	,[be].[FileName__TargetProcessImageFileName]
	,[be].[SourceCommandLine]
	,[be].[TargetCommandLine]
	,[be].[CreateProcess]
	,[be].[CreateRemoteThread]
FROM
	BOTH_EVENTS AS [be]
	INNER JOIN dbo.MachineModulePaths AS [mp] WITH(NOLOCK) ON ([mp].[PK_MachineModulePaths] = [be].[FK_MachineModulePaths])
	INNER JOIN [dbo].[machines] AS [mn] WITH(NOLOCK) ON [mn].[PK_Machines] = [be].[FK_Machines]
WHERE
	[be].[CreateProcess] = 1 AND
	[be].[CreateRemoteThread] = 1 AND
	[mp].[FK_Modules] != -1 AND
	[mp].[MarkedAsDeleted] = 0
OPTION (RECOMPILE);
