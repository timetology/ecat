--Written_by_Monitored_Application.sql	Written by monitored application	1	
--May need to also output the tse details and sfn..


SELECT
	[mn].[MachineName]
	,[sse].[EventUTCTime]
	,[tfn].[FileName]
	,[sse].[Path__TargetProcessPathName]
	,[sse].[FileName__TargetProcessImageFileName]
	,[sse].[SourceCommandLine]
	,[sse].[TargetCommandLine]
	,[tse].[EventUTCTime]
	,[tse].[Path__TargetProcessPathName]
	,[tse].[FileName__TargetProcessImageFileName]
	,[tse].[SourceCommandLine]
	,[tse].[TargetCommandLine]
	
  
FROM 
	[dbo].[uvw_mocSentinelEvents] AS [sse] WITH(NOLOCK)
	INNER JOIN [dbo].[MachineModulePaths] AS [smp] WITH(NOLOCK) ON ([smp].[PK_MachineModulePaths] = [sse].[FK_MachineModulePaths])
	INNER JOIN [dbo].[Modules] AS [mo] WITH(NOLOCK) ON ([mo].[PK_Modules] = [smp].[FK_Modules])
	INNER JOIN [dbo].[uvw_mocSentinelEvents] AS [tse] WITH(NOLOCK) ON ([tse].[HashSHA256__Target] = [mo].[HashSHA256] AND [tse].[FK_Machines] = [smp].[FK_Machines])
	INNER JOIN [dbo].[MachineModulePaths] AS [tmp] WITH(NOLOCK) ON ([tmp].[PK_MachineModulePaths] = [tse].[FK_MachineModulePaths])
	INNER JOIN [dbo].[FileNames] AS [tfn] WITH(NOLOCK) ON ([tfn].[PK_FileNames] = [tmp].[FK_FileNames])
	INNER JOIN [dbo].[machines] AS [mn] WITH(NOLOCK) ON [mn].[PK_Machines] = [sse].[FK_Machines] 


WHERE
	[smp].[FK_Modules] != -1 AND
	(
		[tmp].[BehaviorFileWriteExecutable] = 1 OR
		[tmp].[BehaviorFileRenameToExecutable] = 1
	) AND
	[tfn].[FileName] IN ('WINWORD.EXE','EXCEL.EXE','POWERPNT.EXE','ACRORD32.EXE') AND
	(
		[mo].[ModuleTypeDLL] = 0 AND
		(
			[mo].[ModulePE32] = 1 OR
			[mo].[ModulePE64] = 1
		)
	) AND
	[smp].[MarkedAsDeleted] = 0 -- Testing MarkedAsDeleted on MP instead of SE for Events
OPTION (RECOMPILE);