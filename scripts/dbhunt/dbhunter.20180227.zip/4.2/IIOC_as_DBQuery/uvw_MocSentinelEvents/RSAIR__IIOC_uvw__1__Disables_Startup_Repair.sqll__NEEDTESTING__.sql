--Disables_Startup_Repair.sql	Disables startup repair	1	
   
SELECT
	[mn].[MachineName]
	,[se].[EventUTCTime]
	,[fn].[FileName]
	,[se].[Path__TargetProcessPathName]
	,[se].[FileName__TargetProcessImageFileName]
	,[se].[TargetCommandLine]
	,[se].[TargetCommandLine]
  
FROM [dbo].[uvw_mocSentinelEvents] AS [se] WITH(NOLOCK)
	INNER JOIN [dbo].[machines] AS [mn] WITH(NOLOCK) ON [mn].[PK_Machines] = [se].[FK_Machines] 
	INNER JOIN [dbo].[MachineModulePaths] AS [mp] WITH(NOLOCK) ON ([mp].[PK_MachineModulePaths] = [se].[FK_MachineModulePaths])
	INNER JOIN [dbo].[Modules] AS [mo] WITH(NOLOCK) ON ([mo].[PK_Modules] = [mp].[FK_Modules])
	INNER JOIN [dbo].[FileNames] AS [fn] WITH(NOLOCK) ON ([fn].PK_FileNames = [mp].[FK_FileNames])
WHERE
	[mp].[BehaviorProcessCreateProcess] = 1 AND
	(
		(
			[fn].[FileName] = N'CMD.EXE' AND
			(
				(
					[mo].[ModuleSignatureMicrosoft] = 1 AND
					(
						[se].[TargetCommandLine] LIKE N'%/c%'
						OR
						[se].[SourceCommandLine] LIKE N'%/c%'
					)
				) OR
				(
					[mo].[ModuleSignatureMicrosoft] = 0
				)
			)
		) OR
		(
			[fn].[FileName] != N'CMD.EXE' 
		)
	) AND
	(
		[se].[FileName__TargetProcessImageFileName] = N'BCDEDIT.EXE' AND
		(
			[se].[TargetCommandLine] LIKE N'%/set%recoveryenabled%no' OR
			[se].[TargetCommandLine] LIKE N'%/set%bootstatuspolicy%ignoreallfailures'
		) 
	) AND
	[mp].[MarkedAsDeleted] = 0