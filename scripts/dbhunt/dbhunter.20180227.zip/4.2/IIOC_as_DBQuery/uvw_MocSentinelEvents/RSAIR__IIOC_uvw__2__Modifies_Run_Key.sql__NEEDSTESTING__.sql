--Modifies_Run_Key.sql	Modifies run key	2	
--[BehaviorRegistryModifyRunKey] doesn't exist outside of win tracking events. need to use p0 & p1 for this...

SELECT
      [mn0].[MachineName],
	  [se0].[EventUTCTime],
	  [fn0].[FileName] as 'SourceFilename',
	  [tfn0].[FileName] as 'TargetFilename',
	  [sla0].[LaunchArguments] as 'SourceLaunchArguments',
	  [tla0].[LaunchArguments] as 'TargetLaunchArguments',
      [se0].[Path_Target],
      [se0].[FileName_Target],
      [se0].[LaunchArguments_Target]
	  --,se0.*
FROM
      [dbo].[WinTrackingEvents_P0] AS [se0] WITH(NOLOCK)
      INNER JOIN [dbo].[Machines] AS [mn0] WITH(NOLOCK) ON ([mn0].[PK_Machines] = [se0].[FK_Machines])
      INNER JOIN [dbo].[MachineModulePaths] AS [mp0] WITH(NOLOCK) ON ([mp0].[PK_MachineModulePaths] = [se0].[FK_MachineModulePaths])
      INNER JOIN [dbo].[FileNames] AS [fn0] WITH(NOLOCK) ON ([fn0].[PK_FileNames] = [mp0].[FK_FileNames])
	  INNER JOIN [dbo].[FileNames] AS [tfn0] WITH(NOLOCK) ON ([tfn0].[PK_FileNames] = [se0].[FK_FileNames__TargetProcessImageFileName])
	  INNER JOIN [dbo].[LaunchArguments] AS [sla0] WITH(NOLOCK) ON [sla0].[PK_LaunchArguments] = [se0].[FK_LaunchArguments__SourceCommandLine]
	  INNER JOIN [dbo].[LaunchArguments] AS [tla0] WITH(NOLOCK) ON [tla0].[PK_LaunchArguments] = [se0].[FK_LaunchArguments__TargetCommandLine]
WHERE 
	[se0].[BehaviorRegistryModifyRunKey] = 1 AND
	[mp0].[FK_Modules] != -1 AND
	[mp0].[MarkedAsDeleted] = 0 -- Testing MarkedAsDeleted on MP instead of SE for Events
UNION
SELECT
      [mn1].[MachineName],
	  [se1].[EventUTCTime],
	  [fn1].[FileName] as 'SourceFilename',
	  [tfn1].[FileName] as 'TargetFilename',
	  [sla1].[LaunchArguments] as 'SourceLaunchArguments',
	  [tla1].[LaunchArguments] as 'TargetLaunchArguments',
      [se1].[Path_Target],
      [se1].[FileName_Target],
      [se1].[LaunchArguments_Target]
	  --,se0.*
FROM
      [dbo].[WinTrackingEvents_P1] AS [se1] WITH(NOLOCK)
      INNER JOIN [dbo].[Machines] AS [mn1] WITH(NOLOCK) ON ([mn1].[PK_Machines] = [se1].[FK_Machines])
      INNER JOIN [dbo].[MachineModulePaths] AS [mp1] WITH(NOLOCK) ON ([mp1].[PK_MachineModulePaths] = [se1].[FK_MachineModulePaths])
      INNER JOIN [dbo].[FileNames] AS [fn1] WITH(NOLOCK) ON ([fn1].[PK_FileNames] = [mp1].[FK_FileNames])
	  INNER JOIN [dbo].[FileNames] AS [tfn1] WITH(NOLOCK) ON ([tfn1].[PK_FileNames] = [se1].[FK_FileNames__TargetProcessImageFileName])
	  INNER JOIN [dbo].[LaunchArguments] AS [sla1] WITH(NOLOCK) ON [sla1].[PK_LaunchArguments] = [se1].[FK_LaunchArguments__SourceCommandLine]
	  INNER JOIN [dbo].[LaunchArguments] AS [tla1] WITH(NOLOCK) ON [tla1].[PK_LaunchArguments] = [se1].[FK_LaunchArguments__TargetCommandLine]
WHERE 
	[se1].[BehaviorRegistryModifyRunKey] = 1 AND
	[mp1].[FK_Modules] != -1 AND
	[mp1].[MarkedAsDeleted] = 0 -- Testing MarkedAsDeleted on MP instead of SE for Events
OPTION (RECOMPILE);
