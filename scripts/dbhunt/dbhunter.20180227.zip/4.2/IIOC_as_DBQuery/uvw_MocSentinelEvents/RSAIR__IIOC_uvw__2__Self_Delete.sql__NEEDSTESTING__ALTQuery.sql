--Self_Delete.sql	Self delete	2	
--[BehaviorRegistryModifyRunKey] doesn't exist outside of win tracking events. need to use p0 & p1 for this...

SELECT
	[mn].[MachineName],
	[se].[EventUTCTime],
	[fn].[FileName] as 'SourceFilename',
	[tfn].[FileName] as 'TargetFilename',
	[sla].[LaunchArguments] as 'SourceLaunchArguments',
	[tla].[LaunchArguments] as 'TargetLaunchArguments',
	[se].[Path_Target],
	[se].[FileName_Target],
	[se].[LaunchArguments_Target]
	--,se.*
FROM
	(SELECT * FROM [dbo].[WinTrackingEvents_P0] UNION SELECT * FROM [dbo].[WinTrackingEvents_P1]) AS [se]
	
	INNER JOIN [dbo].[Machines] AS [mn] WITH(NOLOCK) ON ([mn].[PK_Machines] = [se].[FK_Machines])
	INNER JOIN [dbo].[MachineModulePaths] AS [mp] WITH(NOLOCK) ON ([mp].[PK_MachineModulePaths] = [se].[FK_MachineModulePaths])
	INNER JOIN [dbo].[Modules] AS [mo] WITH(NOLOCK) ON ([mo].[PK_Modules] = [mp].[FK_Modules])
	INNER JOIN [dbo].[FileNames] AS [fn] WITH(NOLOCK) ON ([fn].[PK_FileNames] = [mp].[FK_FileNames])
	INNER JOIN [dbo].[FileNames] AS [tfn] WITH(NOLOCK) ON ([tfn].[PK_FileNames] = [se].[FK_FileNames__TargetProcessImageFileName])
	INNER JOIN [dbo].[LaunchArguments] AS [sla] WITH(NOLOCK) ON [sla].[PK_LaunchArguments] = [se].[FK_LaunchArguments__SourceCommandLine]
	INNER JOIN [dbo].[LaunchArguments] AS [tla] WITH(NOLOCK) ON [tla].[PK_LaunchArguments] = [se].[FK_LaunchArguments__TargetCommandLine]
WHERE	
	[se].[BehaviorFileSelfDeleteExecutable] = 1 AND
	[mp].[FK_Modules] != -1 AND
	[mp].[MarkedAsDeleted] = 0 -- Testing MarkedAsDeleted on MP instead of SE for Events
OPTION (RECOMPILE);