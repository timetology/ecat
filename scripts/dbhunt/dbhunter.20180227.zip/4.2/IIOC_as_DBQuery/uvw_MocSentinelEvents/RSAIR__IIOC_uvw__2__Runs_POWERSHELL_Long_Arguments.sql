--Runs_POWERSHELL_Long_Arguments.sql	Runs POWERSHELL.EXE with long arguments	2	
--This will likely produce different results than the IIOC as [se].[TargetCommandLine] includes the PATH whereas [LaunchArguments_Target] does not.
   
SELECT
	[mn].[MachineName]
	,[se].[EventUTCTime]
	,[sfn].[FileName]
	,[se].[Path__TargetProcessPathName]
	,[se].[FileName__TargetProcessImageFileName]
	,[se].[SourceCommandLine]
	,[se].[TargetCommandLine]
  
FROM [dbo].[uvw_mocSentinelEvents] AS [se] WITH(NOLOCK)
	INNER JOIN [dbo].[machines] AS [mn] WITH(NOLOCK) ON [mn].[PK_Machines] = [se].[FK_Machines] 
	INNER JOIN [dbo].[MachineModulePaths] AS [mp] WITH(NOLOCK) ON ([mp].[PK_MachineModulePaths] = [se].[FK_MachineModulePaths])
	INNER JOIN [dbo].[Modules] AS [mo] WITH(NOLOCK) ON ([mo].[PK_Modules] = [mp].[FK_Modules])
	INNER JOIN [dbo].[FileNames] AS [sfn] WITH(NOLOCK) ON ([sfn].[PK_FileNames] = [mp].[FK_FileNames])

WHERE
	[mp].[BehaviorProcessCreateProcess] = 1 AND
	[se].[FileName__TargetProcessImageFileName] = 'POWERSHELL.EXE' AND
	LEN([se].[TargetCommandLine]) >= 499 AND --438 (499-61)
	[mp].[MarkedAsDeleted] = 0