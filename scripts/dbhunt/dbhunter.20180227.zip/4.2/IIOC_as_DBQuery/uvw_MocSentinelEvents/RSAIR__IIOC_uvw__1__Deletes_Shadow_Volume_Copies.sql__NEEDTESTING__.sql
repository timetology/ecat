--Deletes_Shadow_Volume_Copies.sql	Deletes shadow volume copies	1	
   
SELECT
	[mn].[MachineName]
	,[se].[EventUTCTime]
	,[sfn].[FileName]
	,[se].[Path__TargetProcessPathName]
	,[se].[FileName__TargetProcessImageFileName]
	,[se].[SourceCommandLine]
	,[se].[TargetCommandLine]
  
FROM [dbo].[uvw_mocSentinelEvents] AS [se] WITH(NOLOCK)
	INNER JOIN [dbo].[machines] AS [mn] WITH(NOLOCK) ON [mn].[PK_Machines] = [se].[FK_Machines] 
	INNER JOIN [dbo].[MachineModulePaths] AS [mp] WITH(NOLOCK) ON ([mp].[PK_MachineModulePaths] = [se].[FK_MachineModulePaths])
	INNER JOIN [dbo].[Modules] AS [mo] WITH(NOLOCK) ON ([mo].[PK_Modules] = [mp].[FK_Modules])
	INNER JOIN [dbo].[FileNames] AS [sfn] WITH(NOLOCK) ON ([sfn].[PK_FileNames] = [mp].[FK_FileNames])


WHERE
	[mp].[BehaviorProcessCreateProcess] = 1 AND
	(
		(
			[sfn].[FileName] = N'CMD.EXE' AND
			(
				(
					[mo].[ModuleSignatureMicrosoft] = 1 AND
					([se].[TargetCommandLine] LIKE N'%/c%'
					OR
					[se].[SourceCommandLine] LIKE N'%/c%')
				) OR
				(
					[mo].[ModuleSignatureMicrosoft] = 0
				)
			)
		) OR
		(
			[sfn].[FileName] != N'CMD.EXE' 
		)
	) AND
	(
		(
			[se].[FileName__TargetProcessImageFileName] = N'VSSADMIN.EXE' AND
			[se].[TargetCommandLine] LIKE N'%/delete%shadows%/all%/quiet%'
		) OR
		(
			[se].[FileName__TargetProcessImageFileName] = N'WMIC.EXE' AND
			[se].[TargetCommandLine] LIKE N'%shadowcopy%delete%'
		)
	) AND
	[mp].[MarkedAsDeleted] = 0