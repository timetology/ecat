select 
	[mn].[MachineName]
	,sfn.filename
	,mo.HashMD5
	--,mo.HashSHA1
	--,mo.HashSHA256
	,mo.size
	,mo.DaysSinceCompilation
	,mp.DaysSinceCreation
	,mo.NameImportedDLLs
	,mo.SectionsNames
	,mo.Description


 from dbo.MachineModulePaths as mp
INNER JOIN [dbo].[machines] AS [mn] WITH(NOLOCK) ON [mn].[PK_Machines] = [mp].[FK_Machines]
INNER JOIN [dbo].[FileNames] AS [sfn] WITH(NOLOCK) ON ([sfn].[PK_FileNames] = [mp].[FK_FileNames])
INNER JOIN [dbo].[modules] AS [mo] WITH(NOLOCK) ON [mo].[PK_Modules] = [mp].[FK_Modules]
where 
	sfn.filename <> N'cmd.exe'
	AND mo.Description = N'Windows Command Processor'