--===== RSA_IR-SuspiciousActivity_cscript launches javascript wpl ========--
-- Potential javascript downloader activity --

/* ---- DB QUERY ----
SELECT  mn.MachineName, se.EventUTCTime, sfn.Filename, se.FileName_Target, se.Path_Target, se.LaunchArguments_Target, sla.LaunchArguments

FROM
	[dbo].[WinTrackingEvents_P0] AS [se] WITH(NOLOCK) -- Also try P1
	INNER JOIN [dbo].[MachineModulePaths] AS [mp] WITH(NOLOCK) ON ([mp].[PK_MachineModulePaths] = [se].[FK_MachineModulePaths])
	INNER JOIN [dbo].[FileNames] AS [sfn] WITH(NOLOCK) ON ([sfn].[PK_FileNames] = [mp].[FK_FileNames])
	INNER JOIN [dbo].[machines] AS [mn] WITH(NOLOCK) ON [mn].[PK_Machines] = [se].[FK_Machines]
	INNER JOIN [dbo].[LaunchArguments] AS [sla] WITH(NOLOCK) ON [sla].[PK_LaunchArguments] = [se].[FK_LaunchArguments__SourceCommandLine]

WHERE 
	[se].[BehaviorProcessCreateProcess] = 1 
	AND [sfn].Filename = 'cmd.exe' 
	AND se.FileName_Target = 'cscript.exe' 
	AND sla.LaunchArguments LIKE N'%javascript%'
	AND sla.LaunchArguments LIKE N'%.wpl%'

ORDER BY se.EventUTCTime desc
*/


--/* IIOC QUERY
SELECT DISTINCT
	[se].[FK_Machines],
	[se].[FK_MachineModulePaths],
	[se].[PK_WinTrackingEvents] AS [FK_mocSentinelEvents]

FROM
	[dbo].[WinTrackingEventsCache] AS [se] WITH(NOLOCK)
	INNER JOIN [dbo].[Machines] AS [mn] WITH(NOLOCK) ON ([mn].[PK_Machines] = [se].[FK_Machines])
	INNER JOIN [dbo].[MachineModulePaths] AS [mp] WITH(NOLOCK) ON ([mp].[PK_MachineModulePaths] = [se].[FK_MachineModulePaths])
	INNER JOIN [dbo].[FileNames] AS [sfn] WITH(NOLOCK) ON ([sfn].[PK_FileNames] = [mp].[FK_FileNames])
	INNER JOIN [dbo].[LaunchArguments] AS [sla] WITH(NOLOCK) ON [sla].[PK_LaunchArguments] = [se].[FK_LaunchArguments__SourceCommandLine]
	
WHERE 
	[se].[BehaviorProcessCreateProcess] = 1 
	AND [sfn].Filename = 'cmd.exe' 
	AND se.FileName_Target = 'cscript.exe' 
	AND sla.LaunchArguments LIKE N'%javascript%'
	AND sla.LaunchArguments LIKE N'%.wpl%'