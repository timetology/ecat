SELECT 
      MachineName
      ,UserName
	  ,LaunchArguments
      ,TriggerString

 FROM [ECAT$PRIMARY].[dbo].[uvw_mocLinuxCrons] as LC
  INNER JOIN dbo.Machines AS MA WITH(NOLOCK) ON MA.AgentID = LC.AgentID