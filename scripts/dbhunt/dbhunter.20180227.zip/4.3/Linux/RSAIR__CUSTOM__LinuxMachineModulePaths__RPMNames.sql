SELECT distinct 
	mn.machineName,lmmp.RPMName
from uvw_LinuxMachineModulePaths as lmmp
	INNER JOIN [dbo].[machines] AS [mn] WITH(NOLOCK) ON ([mn].[PK_Machines] = [lmmp].[FK_Machines])
where
lmmp.RPMName <> ''

/*
SELECT
	mn.machineName, 
	lmmp.hashSha256, 
	lmmp.Path, 
	lmmp.FileName, 
	lmmp.UserName__FileOwner, 
	lmmp.Usernames_GroupName, 
	lmmp.FileUTCTimeModified, 
	lmmp.FileUTCTimeAccessed, 
	lmmp.FileUTCTimeAttribModified, 
	lmmp.RPMName, 
	lmmp.RPMCategory

	from uvw_LinuxMachineModulePaths as lmmp
	INNER JOIN [dbo].[machines] AS [mn] WITH(NOLOCK) ON ([mn].[PK_Machines] = [lmmp].[FK_Machines])
	*/