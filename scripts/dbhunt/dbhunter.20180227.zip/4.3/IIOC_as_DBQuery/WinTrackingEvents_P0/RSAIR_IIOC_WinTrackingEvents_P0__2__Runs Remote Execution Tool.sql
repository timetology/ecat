--Runs_Remote_Execution_Tool.sql,Runs remote execution tool,2,
SELECT  mn.MachineName
, se.EventUTCTime
, spa.Path as 'SourcePath'
, sfn.Filename  as 'SourceFilename'
, se.FileName_Target
, se.Path_Target
, se.LaunchArguments_Target
, sla.LaunchArguments as 'SourceLaunchArguments'
, se.UserName

FROM
    [dbo].[WinTrackingEvents_P0] AS [se] WITH(NOLOCK)
    LEFT JOIN [dbo].[MachineModulePaths] AS [mp] WITH(NOLOCK) ON ([mp].[PK_MachineModulePaths] = [se].[FK_MachineModulePaths])
    LEFT JOIN [dbo].[FileNames] AS [sfn] WITH(NOLOCK) ON ([sfn].[PK_FileNames] = [mp].[FK_FileNames])
    LEFT JOIN [dbo].[machines] AS [mn] WITH(NOLOCK) ON [mn].[PK_Machines] = [se].[FK_Machines]
    LEFT JOIN [dbo].[LaunchArguments] AS [sla] WITH(NOLOCK) ON [sla].[PK_LaunchArguments] = [se].[FK_LaunchArguments__SourceCommandLine]
    LEFT JOIN [dbo].[paths] as [spa] with(NOLOCK) on [mp].[FK_Paths] = [spa].[PK_Paths]
WHERE 
[se].[BehaviorProcessCreateProcess] = 1 AND 
[se].[FileName_Target] = N'PSEXEC.EXE' OPTION (RECOMPILE);
