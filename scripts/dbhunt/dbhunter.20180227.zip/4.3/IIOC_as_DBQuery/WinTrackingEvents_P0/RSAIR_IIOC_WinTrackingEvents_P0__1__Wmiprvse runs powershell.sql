--Wmiprvse_Runs_Powershell.sql,Wmiprvse runs powershell,1,
SELECT DISTINCT 
[se].[FK_Machines], 
[se].[FK_MachineModulePaths] FROM 
[dbo].[WinTrackingEventsCache] AS [se] WITH(NOLOCK) 
INNER JOIN [dbo].[MachineModulePaths] AS [mp] WITH(NOLOCK) ON ([mp].[PK_MachineModulePaths] = [se].[FK_MachineModulePaths]) 
INNER JOIN [dbo].[FileNames] AS [fn] WITH(NOLOCK) ON ([fn].[PK_FileNames] = [mp].[FK_FileNames]) WHERE 
[fn].[FileName] = 'WMIPRVSE.EXE' AND 
[se].[BehaviorProcessCreateProcess] = 1 AND 
( 

[se].[FileName_Target] = 'POWERSHELL.EXE' OR 

( 


[se].[FileName_Target] = 'CMD.EXE' AND 


[se].[LaunchArguments_Target] LIKE '%CMD%/[C,K]%POWERSHELL%' 

) 
) OPTION (RECOMPILE);