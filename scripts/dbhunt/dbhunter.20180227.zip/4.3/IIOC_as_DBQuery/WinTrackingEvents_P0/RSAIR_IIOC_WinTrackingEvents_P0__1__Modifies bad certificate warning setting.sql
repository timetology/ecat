--Modifies_Bad_Certificate_Warning_Setting.sql,Modifies bad certificate warning setting,1,
SELECT  mn.MachineName
, se.EventUTCTime
, spa.Path as 'SourcePath'
, fn.Filename  as 'SourceFilename'
, se.FileName_Target
, se.Path_Target
, se.LaunchArguments_Target
, sla.LaunchArguments as 'SourceLaunchArguments'

FROM
    [dbo].[WinTrackingEvents_P0] AS [se] WITH(NOLOCK)
    LEFT JOIN [dbo].[MachineModulePaths] AS [mp] WITH(NOLOCK) ON ([mp].[PK_MachineModulePaths] = [se].[FK_MachineModulePaths])
    LEFT JOIN [dbo].[FileNames] AS [fn] WITH(NOLOCK) ON ([fn].[PK_FileNames] = [mp].[FK_FileNames])
    LEFT JOIN [dbo].[machines] AS [mn] WITH(NOLOCK) ON [mn].[PK_Machines] = [se].[FK_Machines]
    LEFT JOIN [dbo].[LaunchArguments] AS [sla] WITH(NOLOCK) ON [sla].[PK_LaunchArguments] = [se].[FK_LaunchArguments__SourceCommandLine]
    LEFT JOIN [dbo].[paths] as [spa] with(NOLOCK) on [mp].[FK_Paths] = [spa].[PK_Paths]
    LEFT JOIN [dbo].[Modules] AS [mo] WITH(NOLOCK) ON ([mo].[PK_Modules] = [mp].[FK_Modules]) WHERE   
[mo].[ModuleSignatureMicrosoft] = 0 AND 
[se].[BehaviorRegistryModifyBadCertificateWarningSetting] = 1 OPTION (RECOMPILE);