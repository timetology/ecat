from ._main import main
main()
